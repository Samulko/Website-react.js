// Define the ENVIRONMENT variable
var ENVIRONMENT = "PRODUCTION"; // Change to "DEVELOPMENT" when testing on local server

$(document).ready(function() {
    var pathPrefix = ENVIRONMENT === "PRODUCTION" ? "/" : "/app-jquery/";
// Load the navigation bar into the <header> tag
$('header').load(pathPrefix + 'header.html', function() {
  // Add click event listeners to navigation links
  $("nav ul li a").click(function() {
    // Remove "active" class from all navigation links
    $("nav ul li").removeClass("active");
    // Add "active" class to clicked navigation link
    $(this).parent().addClass("active");
  });

  // Add "active" class to nav item that matches current page
  var currentUrl = window.location.href;
  $("nav ul li a").each(function() {
    if (currentUrl.includes($(this).attr('href'))) {
      // Remove "active" class from all navigation links
      $("nav ul li").removeClass("active");
      // Add "active" class to current navigation link
      $(this).parent().addClass('active');
    }
  });
});

//Read more/less button
$('.read-more').click(function() {
  $('.description-short').hide();
  $('.description-long').show();
});

$( '.read-less').click(function() {
  $('.description-long').hide();
  $('.description-short').show();
});

// Add click event listener for project thumbnail links
/*
$(document).on("click", ".project-img-container", function(e) {
  if ($(e.target).hasClass("arrow-left") || $(e.target).hasClass("arrow-right")) {
    e.stopPropagation();
    return;
  }

  e.preventDefault();

  const modal = document.getElementById("myModal");
  const fullQualityImage = document.getElementById("fullQualityImage");
  const currentImageSrc = $(this).find(".selected-image").attr("src");

  fullQualityImage.src = currentImageSrc;
  modal.style.display = "block";
  
  // Any additional code inside the event listener should also be commented out
});
*/

  const projectIndex = $(".project-img-container").index(this);
  modal.setAttribute("data-project-index", projectIndex);
  
  const imageUrls = $(this).find('img').map((_, img) => $(img).attr('src')).get();
  $(modal).data('imageUrls', imageUrls);
  $(modal).data('currentIndex', 0);

  console.log('Project Index:', projectIndex); // Debug log
});

// Add click event listener for project images in grid view
$(document).on("click", ".project-link-grid img", function(e) {
  e.preventDefault();
  var projectUrl = $(this).parents('.project-link-grid:first').attr('href');
  if (projectUrl) {
    window.location.href = projectUrl;
  }
});


// Add click event listener for the switch view button
$(document).on("click", ".switch-btn", function() {
  var currentView = window.location.pathname;
  if (currentView.includes("index-grid.html")) {
    window.location.href = "index.html";
  } else {
    window.location.href = "index-grid.html";
  }
});

// Add click event listeners for the arrow buttons
$(document).on("click", ".arrow-left, .arrow-right", function(e) {
  e.preventDefault(); // Prevent the default action of the <a> tag
  e.stopPropagation(); // Stop event from bubbling up to parent elements

  var imageContainer = $(this).closest(".project-img-container");
  var visibleImage = imageContainer.find(".selected-image");
  var nextImage;

  if ($(this).hasClass("arrow-left")) {
    nextImage = visibleImage.prev("img");
    if (nextImage.length === 0) {
      nextImage = imageContainer.find("img").last();
    }
  } else {
    nextImage = visibleImage.next("img");
    if (nextImage.length === 0) {
      nextImage = imageContainer.find("img").first();
    }
  }

  visibleImage.removeClass("selected-image").addClass("hidden-image");
  nextImage.removeClass("hidden-image").addClass("selected-image");

  // Updating the debug log to find all sibling images
  let allSiblings = $(this).closest(".project-img-container").find(".selected-image, .hidden-image");
  console.log('All Siblings:', allSiblings); // Debug log
  console.log('All Siblings Src:', allSiblings.map((index, img) => $(img).attr('src'))); // Debug log
});

// Add click event listener for close button
$(document).on("click", ".close", function() {
  const modal = document.getElementById("myModal");
  modal.style.display = "none";
});

// Add click event listener for modal background
window.onclick = function(event) {
  const modal = document.getElementById("myModal");
  if (event.target === modal) {
    modal.style.display = "none";
  }
};

$(document).ready(function() {
  // When any image with the class 'project-image' is clicked
  $(".project-image").click(function() {
      $("#modalImage").attr("src", $(this).attr("src")); // Set the modal image source to the clicked image source
      $("#myModal").show(); // Show the modal
  });

  // When the close button or modal background is clicked, hide the modal
  $(".close, #myModal").click(function() {
      $("#myModal").hide();
  });

  // Prevent the modal content from closing the modal
  $(".modal-content").click(function(event) {
      event.stopPropagation();
  });
});



  console.log('New Image Src:', newImageSrc); // Debug log

